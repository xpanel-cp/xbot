<?php 

defined('ABSPATH') or die('Access denied!');

if ( $_POST ) {
	
	if ( isset($_POST['XBOT_MerchantID']) ) {
		update_option( 'XBOT_MerchantID', $_POST['XBOT_MerchantID'] );
	}
	
	if ( isset($_POST['XBOT_Address']) ) {
		update_option( 'XBOT_Address', $_POST['XBOT_Address'] );
	}
	
	if ( isset($_POST['XBOT_IsOK']) ) {
		update_option( 'XBOT_IsOK', $_POST['XBOT_IsOK'] );
	}
  
	if ( isset($_POST['XBOT_IsError']) ) {
		update_option( 'XBOT_IsError', $_POST['XBOT_IsError'] );
	}
	
  if ( isset($_POST['XBOT_Unit']) ) {
		update_option( 'XBOT_Unit', $_POST['XBOT_Unit'] );
	}
  
  if ( isset($_POST['XBOT_UseCustomStyle']) ) {
		update_option( 'XBOT_UseCustomStyle', 'true' );
    
    if ( isset($_POST['XBOT_CustomStyle']) )
    {
      update_option( 'XBOT_CustomStyle', strip_tags($_POST['XBOT_CustomStyle']) );
    }
    
	}
  else
  {
    update_option( 'XBOT_UseCustomStyle', 'false' );
  }
  
	echo '<div class="updated" id="message"><p><strong>تنظیمات ذخیره شد</strong>.</p></div>';
	
}
//XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
?>
<h2 id="add-new-user">تنظیمات افزونه XBOT - زرین پال</h2>
<h2 id="add-new-user">جمع تمام پرداخت ها : <?php echo number_format(get_option("XBOT_TotalAmount")); ?>  تومان</h2>
<form method="post">
  <table class="form-table">
    <tbody>
      <tr class="user-first-name-wrap">
        <th><label for="XBOT_MerchantID">آدرس XBOT</label></th>
        <td>
          <input type="text" class="regular-text" value="<?php echo get_option( 'XBOT_Address'); ?>" id="XBOT_Address" name="XBOT_Address">
          <p class="description indicator-hint">https://example.com</p>
        </td>
      </tr>
      
      <tr class="user-first-name-wrap">
        <th><label for="XBOT_MerchantID">کد دروازه پرداخت</label></th>
        <td>
          <input type="text" class="regular-text" value="<?php echo get_option( 'XBOT_MerchantID'); ?>" id="XBOT_MerchantID" name="XBOT_MerchantID">
          <p class="description indicator-hint">XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX</p>
        </td>
      </tr>
      
      <tr>
        <th><label for="XBOT_IsOK">پرداخت صحیح</label></th>
        <td><input type="text" class="regular-text" value="<?php echo get_option( 'XBOT_IsOK'); ?>" id="XBOT_IsOK" name="XBOT_IsOK"></td>
      </tr>
      <tr>
        <th><label for="XBOT_IsError">خطا در پرداخت</label></th>
        <td><input type="text" class="regular-text" value="<?php echo get_option( 'XBOT_IsError'); ?>" id="XBOT_IsError" name="XBOT_IsError"></td>
      </tr>
      
      <tr class="user-display-name-wrap">
        <th><label for="XBOT_Unit">واحد پول</label></th>
        <td>
          <?php $XBOT_Unit = get_option( 'XBOT_Unit'); ?>
          <select id="XBOT_Unit" name="XBOT_Unit">
            <option <?php if($XBOT_Unit == 'تومان' ) echo 'selected="selected"' ?>>تومان</option>
          </select>
        </td>
      </tr>
      
      <tr class="user-display-name-wrap">
        <th>استفاده از استایل سفارشی</th>
        <td>
          <?php $XBOT_UseCustomStyle = get_option('XBOT_UseCustomStyle') == 'true' ? 'checked="checked"' : ''; ?>
          <input type="checkbox" name="XBOT_UseCustomStyle" id="XBOT_UseCustomStyle" value="true" <?php echo $XBOT_UseCustomStyle ?> /><label for="XBOT_UseCustomStyle">استفاده از استایل سفارشی برای فرم</label><br>
        </td>
      </tr>
      
      
      <tr class="user-display-name-wrap" id="XBOT_CustomStyleBox" <?php if(get_option('XBOT_UseCustomStyle') != 'true') echo 'style="display:none"'; ?>>
        <th>استایل سفارشی</th>
        <td>
          <textarea style="width: 90%;min-height: 400px;direction:ltr;" name="XBOT_CustomStyle" id="XBOT_CustomStyle"><?php echo get_option('XBOT_CustomStyle') ?></textarea><br>
        </td>
      </tr>
      
    </tbody>
  </table>
  <p class="submit"><input type="submit" value="به روز رسانی تنظیمات" class="button button-primary" id="submit" name="submit"></p>
</form>

<script>
  if(typeof jQuery == 'function')
  {
    jQuery("#XBOT_UseCustomStyle").change(function(){
      if(jQuery("#XBOT_UseCustomStyle").prop('checked') == true)
        jQuery("#XBOT_CustomStyleBox").show(500);
      else
        jQuery("#XBOT_CustomStyleBox").hide(500);
    });
  }
</script>

