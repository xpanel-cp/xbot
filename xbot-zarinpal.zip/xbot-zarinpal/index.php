<?php
/*
Plugin Name: XBot زرین پال 
Plugin URI: #
Description: پرداخت با درگاه پرداخت ایران برای XBOT
Version: 1.0
Author:  XBOT
Author URI: #
*/

define ('XbotZarinDIR', plugin_dir_path( __FILE__ ));
require_once(XbotZarinDIR. 'XbotZarinpal.php');